<footer>
    <!-- Tabs -->
    <ul class="nav nav-tabs" id="myTab" role="tablist">
        <li class="nav-item">
            <a class="nav-link active" id="link-tab" href="#links">Home</a>
        </li>
        <li class="nav-item">
            <a class="nav-link" id="contact-tab" href="#contact">Contact</a>
        </li>
    </ul>

    <!-- Tabs Content -->
    <div class="tab-content" id="myTabContent">
        <div class="tab-pane active" id="links">
            <ul>
                <li><a href="#">Link 1</a></li>
                <li><a href="#">Link 2</a></li>
                <li><a href="#">Link 3</a></li>
                <li><a href="#">Link 4</a></li>
            </ul>

        </div>
        <div class="tab-pane" id="contact">
            <p>
                Address 1<br>
                1111 ZZ Place<br>
                Country
            </p>
        </div>
    </div>
</footer>
<script src="js/main.js"></script>
</body>
</html>